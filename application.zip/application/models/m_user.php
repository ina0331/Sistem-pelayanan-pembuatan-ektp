<?php
defined('BASEPATH') or exit('No direct Script access allowed');

class m_user extends CI_Model
{
    function login($username,$password){
    return $this->db->query("SELECT * FROM penduduk WHERE username = '$username' AND password='$password' ");
  } 

  function edit_data($where,$table){
    return $this->db->get_where($table,$where);
  }

  function get_data($table){
    return $this->db->get($table);
  }

  function get_data2($table,$id_user){
    $this->db->select('nama_lengkap');
    $this->db->where('id_penduduk',$id_user);
    return $this->db->get($table);
  }

  function insert_data($data,$table){
    $this->db->insert($table,$data);
  }

  function update_data($table,$data,$where){
    $this->db->update($table,$data,$where);
  }

  function delete_data($where,$table){
    $this->db->where($where);
    $this->db->delete($table);
  }
}
?>