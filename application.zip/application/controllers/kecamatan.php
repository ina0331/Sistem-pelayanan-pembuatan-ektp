<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kecamatan extends CI_Controller {


	public function index()
	{
		$this->load->view('index');
	}
	public function beranda()
	{
		$this->load->view('beranda');
	} 
public function about()
  {
    $this->load->view('index');
    $this->load->view('galeri');
  } 

  public function kontak()
  {
    $this->load->view('index');
    $this->load->view('kontak');
  } 

  public function prosedur()
  {
    $this->load->view('index');
    $this->load->view('prosedur');
  } 

  public function pendaftaran()
  {
    if($this->session->userdata('id_penduduk') == ""){
       $this->session->set_flashdata('info','*Anda Harus login dahulu');
        redirect(base_url('kecamatan/login'));
      }else{
    $this->load->view('header');
    $this->load->view('pendaftaran');
  } 
}
	public function daftarakun()
	{
		$this->load->view('daftarakun');
	}

	public function login(){
    if($this->session->userdata('id_penduduk') != ""){
      redirect(base_url('kecamatan'));
    }
      $data['judul'] = "Login";   
      $this->load->view('login',$data);  
  }    

public function login_proses(){
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));

      // num_rows();jumlah isi data table 
      // row_array(); bongkar satuan data table
      // result(); bongkar total table

      $cek_login = $this->m_user->login($username,$password)->num_rows();

       

      // echo $cek_login;

      if ($cek_login==0){
        redirect(base_url('kecamatan/login'));
      }else{
        $data_login = $this->m_user->login($username,$password)->row_array();
        $id_penduduk = $data_login['id_penduduk'];

        $this->session->set_userdata('id_penduduk',$id_penduduk);

        $data_session = $this->m_user->login($username,$password)->row_array();
        // $this->session->set_userdata($id_session);
        redirect('kecamatan');
      }

    }


    function logout(){
    $this->session->sess_destroy();
    redirect(base_url('kecamatan'));
  }

   function daftarakun_act()
   {
      $nama_lengkap = $this->input->post('nama_lengkap');
      $username = $this->input->post('username');
      $password = md5($this->input->post('password'));
      $alamat = $this->input->post('alamat');
      $email = $this->input->post('email');
     
      $this->form_validation->set_rules('nama_lengkap','Nama Lengkap','required');
      $this->form_validation->set_rules('username','Username','required');
      $this->form_validation->set_rules('password','Password','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
    
      if($this->form_validation->run() != false){
          $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username' => $username,
            'password' => $password,
            'alamat' => $alamat,
            'email' => $email,
          
          );
          $this->m_user->insert_data($data,'penduduk');
          $this->session->set_flashdata('info','*Berhasil Mendaftar');
     redirect(base_url('kecamatan/login'));
        }else{
          
          $this->load->view('daftarakun');
        }
      }

    public function pendaftaran_act(){ 
      if($this->session->userdata('id_penduduk') == ""){
        redirect(base_url('kecamatan/login'));
      }else{
      $nama_lengkap = $this->input->post('nama_lengkap');
      $NIK = $this->input->post('NIK');
      $id_penduduk = $this->input->post('id_penduduk');
      $tempat_lahir = $this->input->post('tempat_lahir');
      $tgl_lahir = $this->input->post('tgl_lahir');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $email = $this->input->post('email');
      $alamat = $this->input->post('alamat');
      $agama = $this->input->post('agama');
      $no_telp= $this->input->post('no_telp');
      $waktu_kunjungan= $this->input->post('waktu_kunjungan');
      $this->form_validation->set_rules('nama_lengkap','Nama Lengkap','required');
      $this->form_validation->set_rules('NIK','NIK','required');
      $this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
      $this->form_validation->set_rules('tgl_lahir','Tgl Lahir','required');
      $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required');
      $this->form_validation->set_rules('email','email','required');
      $this->form_validation->set_rules('alamat','Alamat','required');
            if($this->form_validation->run() != false){

        $config['upload_path'] = './assets/images/berkas/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '2048';
        $config['file_name'] = 'gambar'.time();

        $this->load->library('upload',$config);

        if($this->upload->do_upload('KK')){
          $image = $this->upload->data();

          $data = array(
            'KK' => $image['file_name'],
           'id_penduduk' => $this->session->userdata('id_penduduk'),
            'nama_lengkap' => $nama_lengkap,
            'NIK' => $NIK,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'jenis_kelamin' => $jenis_kelamin,
            'email' => $email,
            'alamat' => $alamat,
            'agama' => $agama,
            'no_telp' => $no_telp,
            'waktu_kunjungan' => $waktu_kunjungan,
          );
      
          $this->m_user->insert_data($data,'pendaftaran');
          $this->session->set_flashdata('info','*Berhasil Mendaftar');
           $this->load->view('cetak_bukti');
        }else{

          redirect(base_url('kecamatan/pendaftaran'));
           $this->session->set_flashdata('info','*Tidak dapat Mendaftar');
        }
      }
  }  

}
}

        
	      
  