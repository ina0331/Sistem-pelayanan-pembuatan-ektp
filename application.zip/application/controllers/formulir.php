<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class formulir extends CI_Controller {

function index(){
	  $nama_lengkap = $this->input->post('nama_lengkap');
      $email = $this->input->post('email');
      $no_identitas = $this->input->post('no_identitas');
      $tempat_lahir = $this->input->post('tempat_lahir');
      $tgl_lahir = $this->input->post('tgl_lahir');
      $jenis_kelamin = $this->input->post('jenis_kelamin');
      $tema = $this->input->post('tema');
      $tgl = $this->input->post('tgl');
      $tgl_awal = $this->input->post('tgl_awal');
      $tgl_akhir = $this->input->post('tgl_akhir');
      $pendidikan = $this->input->post('pendidikan');
      $univ = $this->input->post('univ');
      $program_studi = $this->input->post('program_studi');
      $matkul = $this->input->post('matkul');
      $fakultas = $this->input->post('fakultas');
      $no_telp = $this->input->post('no_telp');
      $this->form_validation->set_rules('nama_lengkap','Nama Lengkap','required');
      $this->form_validation->set_rules('no_identitas','NIM','required');
      $this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
      $this->form_validation->set_rules('email','Email','required');
      $this->form_validation->set_rules('no_telp','Nomor Telepon','required');
      $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required');
      $this->form_validation->set_rules('tgl_lahir','Tanggal Lahir','required');
      $this->form_validation->set_rules('tema','Nomor Perusahaan','required');
      $this->form_validation->set_rules('tgl_awal','Tanggal Pelaksanaan','required');
      $this->form_validation->set_rules('tgl_akhir','Tanggal Akhir','required');
      if($this->form_validation->run() != false){

          $data = array(
          	'nama_lengkap' => $nama_lengkap,
            'email' => $email,
            'no_identitas' => $no_identitas,
            'no_telp' => $no_telp,
            'tempat_lahir' => $tempat_lahir,
            'jenis_kelamin' => $jenis_kelamin,
            'tgl_lahir' => $tgl_lahir,
            'tgl_awal' => $tgl_akhir,
            'pendidikan' => $pendidikan,
            'univ' => $univ,
            'program_studi' => $program_studi,
            'matkul' => $matkul,
            'fakultas' => $fakultas, 
          );
          $this->m_user->insert_data($data,'peneliti');
          $this->session->set_flashdata('info','*Berhasil diajukan');
     redirect(base_url('cetak_surat'));
        }else{
          
          $this->load->view('index');
        }
      }
