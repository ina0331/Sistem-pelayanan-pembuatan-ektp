<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admin extends CI_Controller {


	public function index()
	{ if($this->session->userdata('id_admin') == ""){
			redirect(base_url('admin/login'));
		}else{
		$this->load->view('admin/home');
		$this->load->view('admin/dashboard');
	}
}

	public function login(){
 	  	if($this->session->userdata('id_admin') != ""){
			redirect(base_url('admin'));
		}
 	  	$data['judul'] = "Login";   
 	  	$this->load->view('admin/login',$data); 
 	  	
 	  } 

 	  public function login_proses(){
 	  	$username = $this->input->post('username');
 	  	$password = md5($this->input->post('password'));

 	  	// num_rows();jumlah isi data table
 	  	// row_array(); bongkar satuan data table
 	  	// result(); bongkar total table

 	  	$cek_login = $this->m_admin->login($username,$password)->num_rows();

 	  	

 	  	// echo $cek_login;

 	  	if ($cek_login==0){
 	  		redirect(base_url('admin/login'));
 	  	}else{
 	  		$data_login = $this->m_admin->login($username,$password)->row_array();
 	  		$id_admin = $data_login['id_admin'];

 	  		$this->session->set_userdata('id_admin',$id_admin);
	 	  	$data_session = $this->m_admin->login($username,$password)->row_array();
	 	  	// $this->session->set_userdata($id_session);
	 	  	redirect('admin');
 	  	}
 	  	
 	  	}
 	function logout(){
 		$this->session->sess_destroy();
 		redirect(base_url('admin'));
 	}
 	 function pendaftaran(){
 		$data['data_pendaftaran'] = $this->m_admin->get_data('pendaftaran')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/v_pendaftaran',$data);
 	} 

 	 function penduduk(){
 		$data['data_penduduk'] = $this->m_admin->get_data('penduduk')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/v_penduduk',$data);
 	} 

 	function buku_tamu(){
 		$data['data_bukutamu'] = $this->m_admin->get_data('buku_tamu')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/buku_tamu',$data);
 	} 

 	 function data_admin(){
 		$data['data_admin'] = $this->m_admin->get_data('petugas_pelayanan')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/v_admin',$data);
 	} 

 	function data_pesan(){
 		$data['data_pesan'] = $this->m_admin->get_data('pemberitahuan')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/pemberitahuan',$data);
 	} 
 function pesan (){
   
    $data['penduduk'] = $this->m_admin->get_data('penduduk')->result();
    $this->load->view('admin/home');
    $this->load->view('admin/kirim_pesan',$data); 
  }
  function status (){
  
    $this->load->view('admin/home');
    $this->load->view('admin/konfirmasi_status'); 
  }
 
     	 function kirim_pesan()
      {
        if($this->session->userdata('id_admin') == ""){
        redirect(base_url('admin/login'));
      }else{
   $data['id_admin'] =       $this->session->userdata('id_admin');
   $data['id_penduduk']          = $this->input->post('id_penduduk');
    $data['email']          = $this->input->post('email');
    $data['pesan']          = $this->input->post('pesan');
    
    $this->m_user->insert_data($data,'pemberitahuan');
    redirect(base_url('admin/data_pesan'));

}
} 

 function konfirmasi(){
 		$data['data_konfirmasi'] = $this->m_admin->get_data('konfirmasi')->result();
 		$this->load->view('admin/home');
 		$this->load->view('admin/konfirmasi',$data);
 	} 



     	 function ubah_status()
      {
        if($this->session->userdata('id_admin') == ""){
        redirect(base_url('admin/login'));
      }else{
   $data['id_admin'] =       $this->session->userdata('id_admin');
    $data['NIK']          = $this->input->post('NIK');
    $data['status']          = $this->input->post('status');
    
    $this->m_user->insert_data($data,'konfirmasi');
    $this->session->set_flashdata('info','*Berhasil Ditambahkan');
    redirect(base_url('admin/konfirmasi'));

}
}
 public function data_diri(){
    if($this->session->userdata('id_admin') == ""){
        redirect(base_url('admin/login'));
      }else{
      $data['admin'] = $this->m_admin->edit_data(array('id_admin' => $this->session->userdata('id_admin')),'petugas_pelayanan')->result();

      $d=$this->m_admin->edit_data(array('petugas_pelayanan.id_admin' => $this->session->userdata('id_admin')),'petugas_pelayanan')->num_rows();
      $this->load->view('admin/home');
      $this->load->view('admin/data_diri',$data);
    }
  }  

 } 