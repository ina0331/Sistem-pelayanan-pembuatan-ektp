<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>KECAMATAN CIKARANG SELATAN</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="<?php echo base_url()?>assets/img/logo.jpg" rel="icon">
  <link href="<?php echo base_url()?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo base_url()?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo base_url()?>assets/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/lib/animate/animate.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="<?php echo base_url()?>assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: DevFolio
    Theme URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body id="page-top">

  <!--/ Nav Star /-->
  <nav class="navbar navbar-b navbar-trans navbar-expand-md fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll" href="#page-top"><img src="<?php echo base_url()?>assets/img/logo.jpg" width="50" height="50"> KECAMATAN CIKSEL</a>
      <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarDefault"
        aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span></span>
        <span></span>
        <span></span>
      </button>
      <div class="navbar-collapse collapse justify-content-end" id="navbarDefault">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link js-scroll active" href="<?php echo base_url()?>kecamatan">HOME</a>
          </li>
      <li class="nav-item">
            <a class="nav-link js-scroll" href="<?php echo base_url()?>kecamatan/pendaftaran">PENDAFTARAN</a> 
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="<?php echo base_url()?>kecamatan/about">Tentang Kami</a> 
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll" href="<?php echo base_url()?>kecamatan/kontak">KONTAK</a>
          </li>
           <li class="nav-item">
            <a class="nav-link js-scroll" href="<?php echo base_url()?>kecamatan/prosedur">PROSEDUR PENDAFTARAN</a>
          </li>
        
            <?php if($id_penduduk = $this->session->userdata('id_penduduk')) { ?>
           <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#PERSYARATAN" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">  <?php $data_user = $this->m_user->get_data2('penduduk',$id_penduduk)->row_array(); echo $data_user['nama_lengkap'];?></a>
           
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
           
              <a class="dropdown-item" <?php echo anchor('kecamatan/logout', ' &nbsp Logout');?><div class="dropdown-divider"></div></li>

        <?php } else { ?>
             <li class="nav-item"><a class="nav-link js-scroll" <?php echo anchor('kecamatan/login', 'Login');?></li>
        <?php } ?> 
          


        </ul>
      </div>
    </div>
  </nav>
  <!--/ Nav End /-->

  <!--/ Intro Skew Star /-->
  <div id="home" class="intro route bg-image" style="background-image: url(<?php echo base_url()?>assets/img/kecamatan.jpg)">
    <div class="overlay-itro"></div>
    <div class="intro-content display-table">
      <div class="table-cell">
        <div class="container">
          <!--<p class="display-6 color-d">Hello, world!</p>-->
          <h1 class="intro-title mb-4">KANTOR KECAMATAN CIKARANG SELATAN</h1>
          <p class="intro-subtitle">Instansi Pemda Kab.Bekasi<span class="text-slider-items"></span></p>
          <!-- <p class="pt-3"><a class="btn btn-primary btn js-scroll px-4" href="#about" role="button">Learn More</a></p> -->
        </div>
      </div>
    </div>
  </div>
  <!--/ Intro Skew End /-->

 
             
  <a href="<?php echo base_url()?>assets/#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- JavaScript Libraries -->
  <script src="<?php echo base_url()?>assets/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/popper/popper.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/easing/easing.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/counterup/jquery.waypoints.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/counterup/jquery.counterup.js"></script>
  <script src="<?php echo base_url()?>assets/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/lightbox/js/lightbox.min.js"></script>
  <script src="<?php echo base_url()?>assets/lib/typed/typed.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url()?>assets/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url()?>assets/js/main.js"></script>

</body>
</html>
