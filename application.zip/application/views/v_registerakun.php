 <!DOCTYPE html>
 <html> 
 <head> 
  <meta charset="utf-8"> <title>Booking Ballroom | Meeting</title>
   <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/stylebook.css">
</head>
      <div id="wrapper"> 
    <header>
      <hgroup> 
        <h1>Booking Balroom</h1> 
        <h3>Membuat Pertemuan yang nyaman</h3> 
        
      </hgroup>
      <center>
      <body background="<?php echo base_url() ?>assets/images/us.JPEG" rel='shortcut icon'>
      </center>
       </header> 
 
      <section> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/stylebooking.css">
  <div class="box-form">
    <h2 align="center">Form Pendaftaran Sebagai Member</h2><hr><br>
    <form action="<?php echo base_url().'kesbang/register_akun_act' ?>" method="post">
<br>
<font color=blue><p align="right"><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  <div class="alert alert-danger alert-success">
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></p></font>
<br>
<br>
<label> Nama Lengkap  :  </label></br>
      <input name="nama_lengkap" type="text" required="" placeholder="Masukkan Nama Lengkap Anda" /></br><br>

<label> Username  :  </label></br>
      <input name="username" type="text" required="" placeholder="Masukkan Username Anda" /></br><br>

<label> Password :  </label></br>
      <input name="password" type="password" required="" placeholder="Masukkan Password Anda" /></br><br>

<label> Nomor Telepon :  </label></br>
      <input name="no_telp" type="number" required="" placeholder="Masukkan Nomer telpon Anda" /></br><br>

<label> Alamat Email :  </label></br>
      <input name="email" type="text" required="" placeholder="Masukkan Alamat Email Anda" /></br><br>

<br>
<br>

  <center>
      <input type="submit" name="simpan" value="Simpan" /> 
      &nbsp;&nbsp; <input type="reset" value="Batal" />
    </center>

<p> Sudah punya akun ? <a href="<?php echo base_url() ?>kesbang/login">LOGIN</a></p>
</form>
  </td>
    </tr>
      </table>
</section>
</div>
</br></br>
</section>
</section>
<footer> 
            <a href="http://booking_ballroom">BookingBallroom</a> 
          </footer> 
        </div> 
       </body> 
       </html>
 