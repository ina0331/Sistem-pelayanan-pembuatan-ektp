<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body>
 <style type="text/css">
 .table-data{
   width: 100%;
   border-collapse: collapse;
  }
 
  .table-data tr th,
  .table-data tr td{
   border:1px solid black;
   font-size: 10pt;
  }
 </style>
<img src="<?= base_url();?>assets/img/logo.png" width=100% height=25% />
<h3 align="center"> SURAT PEMBERITAHUAN </h3>

 <?php
 $NIK = $_POST['NIK'];
 $nama_lengkap = $_POST['nama_lengkap'];
 $waktu_kunjungan = $_POST['waktu_kunjungan'];
 $waktu_kunjungan = date('d F Y',strtotime($waktu_kunjungan)); 
 

?>
  &nbsp;
 <table class="table-data">
</tr>
<p>Assalamualaikum. Wr.Wb<br>
<p>Kepada penduduk Cikarang Selatan Kabupaten Bekasi dibawah ini atas : <br>
<p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;NIK &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;  : <?php echo $NIK;?><br>
<p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Nama Lengkap &nbsp; &nbsp; &nbsp; &nbsp; : <?php echo $nama_lengkap;?><br>
<p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Waktu Kunjungan  &nbsp; &nbsp; : <?php echo $waktu_kunjungan;?><br>
<br>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Untuk segera mendatangi Kantor Kecamatan Cikarang Selatan guna mengambil E-KTP yang telah tercetak. Demikian pemberitahuan yang kami sampaikan, untuk secepatnya ditindaklanjuti. Terima kasih.<br>
<p>Wassalamualaikum Wr.Wb.<br>
<p align="center">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; Cikarang Selatan,&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;2020<br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
<p align="center">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; Petugas Pelayanan

  
 </tbody>
</table>

<script type="text/javascript">
 window.print();
</script>

</body>
</html>