<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN THEME CUSTOMIZER-->
						<div id="theme">
							
							<span class="settings">
                                <span class="text"></span>
                                <span class="colors">
                                    <span class="color-default" data-style="default"></span>
                                    <span class="color-gray" data-style="gray"></span>
                                    <span class="color-purple" data-style="purple"></span>
                                    <span class="color-navy-blue" data-style="navy-blue"></span>
                                </span>
							</span>
						</div>
						<!-- END THEME CUSTOMIZER-->
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					
						<ul class="breadcrumb">
							<li>
                                <a href="#"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="#">Admin</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">Data Konfirmasi</a><span class="divider-last">&nbsp;</span></li>
                            
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<div id="page-wrapper">
            <div id="page-inner">
              
                    <div class="col-md-12"><div class="page-header">
  <h3 align="center">DAFTAR KONFIRMASI</h3>
</div>
 <a href="<?php echo base_url().'admin/status'; ?>" class="btn btn-primary btn-xs"><span class="glyphicon glyphicon-plus"></span> Tambah Status Konfirmasi</a>
<br><br> 
<font color=blue><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></font>
<br>
<div class="table-responsive">
  <table class="table table-bordered table-striped table-hover">
    <thead>
      <tr>
        <th>No</th>
        <th>ID Admin</th>
        <th>NIK</th>  
        <th>Status</th>  
       
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      foreach ($data_konfirmasi as $a) {
      ?>
      <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $a->id_admin?></td>
        <td><?php echo $a->NIK ?></td>
        <td><?php echo $a->status ?></td>
       
      </tr>
    <?php } ?>
  </tbody>
</table>
</div>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>



                        </div>
					</div>
				</div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<div id="footer">
		2020 &copy; Admin Dashboard.
		<div class="span pull-right">
			<span class="go-top"><i class="icon-arrow-up"></i></span>
		</div>
	</div>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS -->
	<!-- Load javascripts at bottom, this will reduce page load time -->
	<script src="<?php echo base_url()?>assets1/js/jquery-1.8.3.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/jquery-slimscroll/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/fullcalendar/fullcalendar/fullcalendar.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url()?>assets1/js/jquery.blockui.js"></script>
	<script src="<?php echo base_url()?>assets1/js/jquery.cookie.js"></script>
	<!-- ie8 fixes -->
	<!--[if lt IE 9]>
	<script src="js/excanvas.js"></script>
	<script src="js/respond.js"></script>
	<![endif]-->
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.russia.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.world.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.europe.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.germany.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.usa.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/data/jquery.vmap.sampledata.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jquery-knob/js/jquery.knob.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.resize.js"></script>

    <script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.crosshair.js"></script>

	<script src="<?php echo base_url()?>assets1/js/jquery.peity.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>assets1/assets/uniform/jquery.uniform.min.js"></script>
	<script src="<?php echo base_url()?>assets1/js/scripts.js"></script>
	<script>
		jQuery(document).ready(function() {
			// initiate layout and plugins
			App.setMainPage(true);
			App.init();
		});
	</script>
	<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>