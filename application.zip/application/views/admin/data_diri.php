<div id="main-content">
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN THEME CUSTOMIZER-->
						<div id="theme">
							
							<span class="settings">
                                <span class="text"></span>
                                <span class="colors">
                                    <span class="color-default" data-style="default"></span>
                                    <span class="color-gray" data-style="gray"></span>
                                    <span class="color-purple" data-style="purple"></span>
                                    <span class="color-navy-blue" data-style="navy-blue"></span>
                                </span>
							</span>
						</div>
						<!-- END THEME CUSTOMIZER-->
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					
						<ul class="breadcrumb">
							<li>
                                <a href="#"><i class="icon-home"></i></a><span class="divider">&nbsp;</span>
							</li>
                            <li>
                                <a href="#">PROFIL</a> <span class="divider">&nbsp;</span>
                            </li>
							<li><a href="#">Data Diri</a><span class="divider-last">&nbsp;</span></li>
                            
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				 <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12"><div class="page-header">
	<h3 style="position: relative; right: : 25%" align="center">&nbsp;&nbsp;Data Admin</h3>
</div>
<div style="position: relative; right: : 25%">
<table>
	<?php 
	// echo print_r($siswa);
		foreach ($admin as $e) {
	?>
	<tr><th><h5 style="position: relative; right: : 75%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama Petugas</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->nama_lengkap; ?></th></tr>
	<tr><th><h5 style="position: relative; right: : 75%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbspUsername</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->username; ?></th></tr>
	<tr><th><h5 style="position: relative; right: : 25%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbspNIP</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->NIP; ?></th></tr>
	<tr><th><h5 style="position: relative; right: : 25%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbspId Admin</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->id_admin; ?></th></tr>
	<tr><th><h5 style="position: relative; right: : 25%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Alamat</th><th>&nbsp;:&nbsp;</th><th><?php echo $e->alamat; ?></th></tr>
	<?php } ?>
				</tbody>
				</table>
			</div>
		</td>
	</tr>
	<tr>
		&nbsp;
		<br><br>
		<td colspan="3">
		<td align="left">
			<h5 style="position: relative; right: : 25%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="btn btn-sm btn-primary" href="<?php echo base_url().'admin'; ?>"><span class="glyphicon glyphicon-delete"></span> kembali</a>
		</td>
		<td>
	</tr>
</table>
</div>
</div>

                                                          <div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </li>



                        </div>
					</div>
				</div>
				<!-- END PAGE CONTENT-->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<div id="footer">
		2020 &copy; Admin Dashboard.
		<div class="span pull-right">
			<span class="go-top"><i class="icon-arrow-up"></i></span>
		</div>
	</div>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS -->
	<!-- Load javascripts at bottom, this will reduce page load time -->
	<script src="<?php echo base_url()?>assets1/js/jquery-1.8.3.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/jquery-slimscroll/jquery-ui-1.9.2.custom.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/fullcalendar/fullcalendar/fullcalendar.min.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url()?>assets1/js/jquery.blockui.js"></script>
	<script src="<?php echo base_url()?>assets1/js/jquery.cookie.js"></script>
	<!-- ie8 fixes -->
	<!--[if lt IE 9]>
	<script src="js/excanvas.js"></script>
	<script src="js/respond.js"></script>
	<![endif]-->
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.russia.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.world.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.europe.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.germany.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/maps/jquery.vmap.usa.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/data/jquery.vmap.sampledata.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>assets1/assets/jquery-knob/js/jquery.knob.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.js"></script>
	<script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.resize.js"></script>

    <script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url()?>assets1/assets/flot/jquery.flot.crosshair.js"></script>

	<script src="<?php echo base_url()?>assets1/js/jquery.peity.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>assets1/assets/uniform/jquery.uniform.min.js"></script>
	<script src="<?php echo base_url()?>assets1/js/scripts.js"></script>
	<script>
		jQuery(document).ready(function() {
			// initiate layout and plugins
			App.setMainPage(true);
			App.init();
		});
	</script>
	<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>