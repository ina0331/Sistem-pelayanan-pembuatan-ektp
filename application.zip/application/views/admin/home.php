<!DOCTYPE html>
<!--
Template Name: Admin Lab Dashboard build with Bootstrap v2.3.1
Template Version: 1.2
Author: Mosaddek Hossain
Website: http://thevectorlab.net/
-->

<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title> Admin | Kec.Ciksel</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<link href="<?php echo base_url()?>assets1/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo base_url()?>assets1/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
	<link href="<?php echo base_url()?>assets1/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
	<link href="<?php echo base_url()?>assets1/css/style.css" rel="stylesheet" />
	<link href="<?php echo base_url()?>assets1/css/style_responsive.css" rel="stylesheet" />
	<link href="<?php echo base_url()?>assets1/css/style_default.css" rel="stylesheet" id="style_color" />

	<link href="<?php echo base_url()?>assets1/assets/fancybox/source/jquery.fancybox.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets1/assets/uniform/css/uniform.default.css" />
	<link href="<?php echo base_url()?>assets1/assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
	<link href="<?php echo base_url()?>assets1/assets/jqvmap/jqvmap/jqvmap.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
	<!-- BEGIN HEADER -->
	<div id="header" class="navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="navbar-inner">
			<div class="container-fluid">
				<!-- BEGIN LOGO -->
				<a class="brand" href="<?php echo base_url()?>assets1/ index.html">
				   <i class="icon-dashboard"></i> ADMIN
				</a>
				<!-- END LOGO -->
				<!-- BEGIN RESPONSIVE MENU TOGGLER -->
				<a class="btn btn-navbar collapsed" id="main_menu_trigger" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="arrow"></span>
				</a>
				<!-- END RESPONSIVE MENU TOGGLER -->
				<div id="top_menu" class="nav notify-row">
                    <!-- BEGIN NOTIFICATION -->
					<ul class="nav top-menu">
                        <!-- BEGIN SETTINGS -->
                        <li class="dropdown">
                            <a class="dropdown-toggle element" data-placement="bottom" data-toggle="tooltip" href="#" data-original-title="Settings">
                                <i class="icon-cog"></i>
                            </a>
                        </li>
                        <!-- END SETTINGS -->
                        <!-- BEGIN INBOX DROPDOWN -->
                        
                        <!-- END INBOX DROPDOWN -->
						<!-- BEGIN NOTIFICATION DROPDOWN -->
						
						<!-- END NOTIFICATION DROPDOWN -->

					</ul>
                </div>
                    <!-- END  NOTIFICATION -->
                <div class="top-nav ">
                    <ul class="nav pull-right top-menu" >
                        <!-- BEGIN SUPPORT -->
                        <li class="dropdown mtop5">

                            
                        </li>
                        
                        <!-- END SUPPORT -->
						<!-- BEGIN USER LOGIN DROPDOWN -->
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo base_url()?>assets1/img/avatar.png">
                               <?php if($id_admin = $this->session->userdata('id_admin')) { ?>
            <?php $data_user = $this->m_admin->get_data2('petugas_pelayanan',$id_admin)->row_array(); echo $data_user['nama_lengkap'];?> 
             <?php } ?> 
							<b class="caret"></b>
							</a>
							<ul class="dropdown-menu">
								<li><a href="<?php echo base_url()?>admin/data_diri"><i class="icon-user"></i> My Profile</a></li>
							
								<li class="divider"></li>
								<li><a href="<?php echo base_url()?>admin/logout"><i class="icon-key"></i> Log Out</a></li>
							</ul>
						</li>
						<!-- END USER LOGIN DROPDOWN -->
					</ul>
					<!-- END TOP NAVIGATION MENU -->
				</div>
			</div>
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div id="container" class="row-fluid">
		<!-- BEGIN SIDEBAR -->
		<div id="sidebar" class="nav-collapse collapse">
			<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
			<div class="sidebar-toggler hidden-phone"></div>
			<!-- BEGIN SIDEBAR TOGGLER BUTTON -->

			<!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
			<div class="navbar-inverse">
				<form class="navbar-search visible-phone">
					<input type="text" class="search-query" placeholder="Search" />
				</form>
			</div>
			<!-- END RESPONSIVE QUICK SEARCH FORM -->
			<!-- BEGIN SIDEBAR MENU -->
			<ul class="sidebar-menu">
				<li class="has-sub active">
					<a href="<?php echo base_url()?>admin" class="">
					    <span class="icon-box"> <i class="icon-dashboard"></i></span> Dashboard
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">
                        	

                    </ul>
				</li>
				<li class="has-sub">
					<a href="<?php echo base_url()?>admin/pendaftaran" class="">
					    <span class="icon-box"> <i class="icon-book"></i></span> Pendaftaran
					    <span class="arrow"></span>
					</a>
					
				</li>
				<li class="has-sub">

				
				<li class="has-sub active">
					<a href="<?php echo base_url()?>admin/penduduk" class="">
					    <span class="icon-box"> <i class="icon-user"></i></span> Data Penduduk
                        <span class="arrow"></span>
                    </a>
                 

                <li class="has-sub">
					<a href="<?php echo base_url()?>admin/data_pesan" class="">
					    <span class="icon-box"> <i class="icon-tag"></i></span> Pemberitahuan
					    <span class="arrow"></span>
					</a>
					
				</li>
				<li class="has-sub">  

				<li class="has-sub active">
					<a href="<?php echo base_url()?>admin/data_admin" class="">
					    <span class="icon-box"> <i class="icon-user"></i></span> Data Petugas
                        <span class="arrow"></span>
                    </a>
              	


                <li class="has-sub">
					<a href="<?php echo base_url()?>admin/konfirmasi" class="">
					    <span class="icon-box"> <i class="icon-tag"></i></span> Konfirmasi
					    <span class="arrow"></span>
					</a>
					
				</li>
				<li class="has-sub">  

					<li class="has-sub">  

				<li class="has-sub active">
					<a href="<?php echo base_url()?>admin/buku_tamu" class="">
					    <span class="icon-box"> <i class="icon-book"></i></span> Buku Tamu
                        <span class="arrow"></span>
                    </a>
                    <ul class="sub">  	




					
			<!-- END SIDEBAR MENU -->
		</div>
		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->
		