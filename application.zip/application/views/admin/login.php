<!DOCTYPE html>
<html>
<head>
	<title> LOGIN ADMIN</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>style.css">
</head>
<body>
	<div class="login-box">
		<img src="<?php echo base_url()?>avatar.jpg" class="avatar" >
	<h1>Login here</h1>
 <form action="<?php echo base_url().'admin/login_proses' ?>" method="post">
		<input type="text" name="username" placeholder="Enter username" >
		<p>password</p>
		<input type="password" name="password" placeholder="Enter password" >
		
		<input type="submit" name="submit" value="login"></a>
		
	</form>

	 </div>

</body>
</html> 