<section class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url(img/overlay-bg.jpg)">
    <div class="overlay-mf"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="contact-mf">
            <div id="contact" class="box-shadow-full">
              <div class="row">
                <div class="col-md-12">
                  <div class="title-box-2">
                    <h2 align="center">
                      Form Pendaftaran E-KTP
                    </h5>
                  </div>
                  <div>
                      <form action="<?php echo base_url().'kecamatan/pendaftaran_act' ?>" method="post" enctype="multipart/form-data">
<font color=blue><p align="right"><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  <div class="alert alert-danger alert-success">
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></p></font>
                      <div id="sendmessage">Your message has been sent. Thank you!</div>
                      <div id="errormessage"></div>
                      <div class="row">
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Nama Lengkap :</b>
                            <input type="text" name="nama_lengkap" class="form-control" id="nama" placeholder="Masukkan Nama Lengkap"/>
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Nomor Induk Kepedudukan :</b>
                            <input type="number" class="form-control" name="NIK" id="NIK" placeholder="Masukkan NIK Anda" />
                            <div class="validation"></div>
                          </div>
                        </div>
                          <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Tempat Lahir :</b>
                            <input type="text" class="form-control" name="tempat_lahir" id="tempat_lahir" placeholder="Masukkan Tempat Lahir Anda" />
                          </div>
                        </div>
                         <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Tanggal Lahir :</b>
                            <input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" placeholder="Masukkan Tanggal Lahir Anda" />
                          </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                           <b>Jenis Kelamin</b>
          <select name="jenis_kelamin" class="form-control" data-rule="" placeholder="-Pilih-">
            <option value="Laki-Laki">Laki-Laki</option>
            <option value="Perempuan">Perempuan</option>
          </select>
        </div>
      </div> 
       <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Agama :</b>
                            <input type="text" class="form-control" name="agama" id="agama" placeholder="Masukkan Agama Anda" />
                          </div>
                        </div>

                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Email :</b>
                            <input type="text" class="form-control" name="email" id="email" placeholder="Masukkan Email Anda" />
                            <div class="validation"></div>
                          </div>
                        </div>
                         <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Nomor Telepon :</b>
                            <input type="number" class="form-control" name="no_telp" id="no_telp" placeholder="Masukkan No.Telepon Anda" />
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Alamat :</b>
                            <textarea class="form-control" name="alamat" rows="5" data-rule="required" placeholder="Masukkan Alamat Lengkap Anda"></textarea>
                            <div class="validation"></div>
                           </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Kartu Keluarga :</b>
                             <input type="file" class="form-control" name="KK" id="KK" placeholder="Masukkan foto KK Anda" />
                              <small><font color=red>*file maksimal dengan ukuran 2MB PNG/JPG/JPEG</font></small>
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12 mb-3">
                          <div class="form-group">
                            <b>Waktu Kunjungan :</b>
                            <input type="date" class="form-control" name="waktu_kunjungan" id="waktu_kunjungan" placeholder="Masukkan No.Telepon Anda" />
                            <div class="validation"></div>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <button type="submit" class="button button-a button-big button-rouded">Simpan</button>
                           <button type="reset" class="btn btn-danger button-big button-rouded">Batal</button>
                        </div>
                      </div>
                    </form>
                  </div> 
                </div>
                
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


 
    <footer>
                  
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </section>
  <!--/ Section Contact-footer End /-->
