<!DOCTYPE html>
<html>
<head>
	<title> Log in </title>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/style.css">
</head>
<body>
<form action="<?php echo base_url().'kecamatan/login_proses' ?>" method="post" class="box" >
	<br>
<font color=green><p align="right"><b><?php 
$info = $this->session->flashdata('info');
if($info)
{?>
  <div class="alert alert-danger alert-success">
  <i class="icon-ok green"></i>
<?php
echo $info;
}
?></b></p></font>
	<h3>Selamat datang di Website Pelayanan Administrasi Pembuatan E-KTP</h3>
	<h1>---Log In---</h1>
	<input type="text" name="username" placeholder="Username">
	<input type="password" name="password" placeholder="password">
	<input type="submit" name="" value="Log In">
	<p><font color="white">Belum punya akun ? <a href="<?php echo base_url() ?>kecamatan/daftarakun">Daftar disini
</body>
</html>