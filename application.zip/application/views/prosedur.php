
  <section id="about" class="about-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="box-shadow-full">
            <div class="row">
              <div class="col-md-6">
                <div class="row">
                  <div class="col-sm-6 col-md-5">
                    <div class="about-img">
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-7">
                    <div class="lead">
                      
                    </div>
                  </div>
                </div>
                <div class="lead">
                 
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="about-me pt-4 pt-md-0">
                  <div class="title-box-2">
                    <h5 class="title-left" align="center">
                     <center>PROSEDUR PENDAFTARAN</center> 
                    </h5>
                  </div>
                  <h4>
                    
                   <b>Persyaratan :</b>
                 </h4>
                    <p>
<strong><i>Persyaratan yang dibutuhkan hanyalah Kartu Keluarga</i>
</strong>
 <h4>
<b>Prosedur Pembuatan E-KTP :</b>
</h4>
 <p>
1.  Langkah pertama yang harus dilakukan membuka website pelayanan administrasi pembuatan E-KTP</p>
2.  Daftar akun (sign in) terlebih dahulu jika belum mempunyao akun</p>
3.  Berikutnya log in</p>
4.  Kemudian pilih menu daftar pembuatan E-KTP </p>
5.  Isi form pendaftaran pembuatan E-KTP</p>
6.  Upload berkas persyaratan yaitu scan Kartu Keluarga</p>
7.  Pilih waktu kunjungan </p>
8.  Kemudian cetak bukti pendaftaran</p>
9.  Setelah mencetak bukti pendaftaran, penduduk mendatangi kantor kecamatan sesuai waktu kunjungan yang di pilih</p>
10. Kemudian penduduk akan diarahkan ke ruang E-KTP untuk perekaman data diri</p>
11. Jika penduduk sudah pernah melakukan perekaman dan data masih ada maka penduduk hanya menunggu cetak E-KTP saja</p>
12. Setelah kurang lebih 3 hari E-KTP telah tercetak</p> 
13. Kemudian petugas pelayanan akan mengirim pemberitahuan kepada penduduk agar E-KTP segera diambil</p>

                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
 

  </section>