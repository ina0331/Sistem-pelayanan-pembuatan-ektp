<section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
            <h3 class="title-a">
              GALERI KECAMATAN
            </h3>
           
            <div class="line-mf"></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="work-box">
            <a href="<?php echo base_url()?>assets/img/kecamatan.jpg" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="<?php echo base_url()?>assets/img/kecamatan.jpg" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Foto Bersama dengan lainnya</h2>
                    <div class="w-more">
                      <span class="w-date">02 DES. 2019</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                     
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="<?php echo base_url()?>assets/img/foto.jpg" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="<?php echo base_url()?>assets/img/foto.jpg" alt="" class="img-fluid">
              </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">kegiatan Upacara setiap Hari Senin</h2>
                    <div class="w-more">
                    <span class="w-date">02 DES. 2019</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                     
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="work-box">
            <a href="<?php echo base_url()?>assets/img/img.jpeg" data-lightbox="gallery-mf">
              <div class="work-img">
                <img src="<?php echo base_url()?>assets/img/img.jpeg" alt="" class="img-fluid">
             </div>
              <div class="work-content">
                <div class="row">
                  <div class="col-sm-8">
                    <h2 class="w-title">Lapangan Parkir Kantor Kecamatan</h2>
                    <div class="w-more">
                      <span class="w-date">18 Sep. 2018</span>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="w-like">
                     
                    </div>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
      
        
      </div>
    </div>
  </section>



   <section id="work" class="portfolio-mf sect-pt4 route">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="title-box text-center">
                     <h3 class="title-a">

                     <center>Visi Dan Misi Kecamatan Cikarang Selatan</center> 
                    </h5>
                  </div>
                  <h3>
                    
                   <b>a. Visi</b></h3>

                  </p>
                  <p class="lead" align="justify">
                   <strong>Visi kecamatan Cikarnag Selatan Kabupaten Bekasi adalah “Terwujudnya Kecamatan Cikarang Selatan yang unggul dalam pelayanan prima melalui penyelenggaraan administrasi pemerintahan yang akuntabel”. Visi ini dimaksudkan untuk mewujudkan apatur pemerintahan dan masyarakat yang berkualitas dalam mewujudkan kawasan Kecamatan Cikarang Selatan sebagai Kawasan pemukiman dan industri.</strong>

                  </p>
                  <h3>
                    
                   <b>b. Misi</b></h3>
                 </p>
                  <p class="lead" align="justify">
                  <strong>Untuk mewujudkan visi yang dimaksud menjadi hal kongkrit, Kecamatan Cikarang Selatan Kabupaten Bekasi telah menetapkan Misi, Yaitu “Mewujudkan pelaksanaan pelimpahan sebagain kewenangan Bupati yang dilimpahkan Kepada Camat, memberikan pelayanan prima kepada masyarakat dan meningkatkan pelenggaraan administrasi pemerintahan”. Tujuannya untuk mewujudkan kualitas pelayanan administrasi yang responsive, profesional, cepat dan akurat kepada masyarakat. Sasarannya adalah efektifitas dalam pelayanan kepada masyarakat dan kualitas penyelenggaraan administrasi pemerintahan terjamin.</strong>

                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
 

  </section>

