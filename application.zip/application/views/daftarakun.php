<!DOCTYPE html>
<html>
<head>
	<title> Register Akun </title>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/style.css">
</head>
<body>
<form action="<?php echo base_url().'kecamatan/daftarakun_act' ?>" method="post" class="box" >
	<h3>Selamat datang di Website Pelayanan Administrasi Pembuatan E-KTP</h3>
	<h1>---Daftar Akun Baru---</h1>
	<input type="text" name="username" placeholder="Username">
	<input type="text" name="nama_lengkap" placeholder="Nama Lengkap">
	<input type="password" name="password" placeholder="password">
	<input type="text" name="email" placeholder="email">
	<input type="text" name="alamat" placeholder="Alamat">
	
	<input type="submit" name="" value="Daftar">
	<p><font color="white">Sudah punya akun ? <a href="<?php echo base_url() ?>kecamatan/login">Login
</body>
</html>